package com.example.subtitle

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private var size = 22f
    private var color = Color.WHITE
    private var lang = "en"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(perms.toTypedArray(), 1)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(40, 60, 40, 40)

        fun btn(t: String, f: () -> Unit) {
            val b = Button(this)
            b.text = t
            b.setOnClickListener { f() }
            root.addView(b)
        }

        btn("1. Cấp quyền hiển thị trên app khác") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }

        val rg = RadioGroup(this)
        val rEn = RadioButton(this)
        rEn.text = "Tiếng Anh → Việt"
        rEn.id = 1
        val rZh = RadioButton(this)
        rZh.text = "Tiếng Trung → Việt"
        rZh.id = 2
        rg.addView(rEn)
        rg.addView(rZh)
        rg.check(1)
        rg.setOnCheckedChangeListener { _, id -> lang = if (id == 2) "zh" else "en" }
        root.addView(rg)

        btn("2. Bắt đầu dịch") { begin() }
        btn("Dừng") { stopService(Intent(this, OverlayService::class.java)) }

        val label = TextView(this)
        label.text = "Cỡ chữ"
        root.addView(label)
        val sb = SeekBar(this)
        sb.max = 40
        sb.progress = 12
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                size = 10f + p
                sendStyle()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(sb)

        val colors = listOf(
            "Trắng" to Color.WHITE, "Vàng" to Color.YELLOW,
            "Xanh lá" to Color.GREEN, "Xanh dương" to Color.CYAN
        )
        for ((name, c) in colors) {
            btn("Màu $name") {
                color = c
                sendStyle()
            }
        }

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun sendStyle() {
        startService(
            Intent(this, OverlayService::class.java).setAction("style")
                .putExtra("size", size).putExtra("color", color)
        )
    }

    private fun begin() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Hãy cấp quyền ở bước 1 trước", Toast.LENGTH_LONG).show()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Hãy cho phép quyền ghi âm rồi bấm lại", Toast.LENGTH_LONG).show()
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mpm.createScreenCaptureIntent(), 100)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, OverlayService::class.java).setAction("start")
                .putExtra("code", resultCode).putExtra("data", data)
                .putExtra("lang", lang).putExtra("size", size).putExtra("color", color)
            startForegroundService(i)
        }
    }
}
