package com.example.subtitle

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

class OverlayService : Service() {
    private val ui = Handler(Looper.getMainLooper())
    private var tv: TextView? = null
    private lateinit var wm: WindowManager
    private var projection: MediaProjection? = null
    private var translator: Translator? = null
    @Volatile private var running = false
    private var seq = 0
    private var applied = 0
    private val clearer = Runnable { show("") }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val ch = NotificationChannel("sub", "Subtitle", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "start" -> startAll(intent)
            "style" -> if (tv == null) stopSelf() else applyStyle(intent)
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startAll(i: Intent) {
        if (running) return
        running = true
        val n = Notification.Builder(this, "sub")
            .setContentTitle("Sub Overlay đang chạy")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        addOverlay()
        applyStyle(i)
        val lang = i.getStringExtra("lang") ?: "en"
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val p = mpm.getMediaProjection(i.getIntExtra("code", 0), i.getParcelableExtra<Intent>("data")!!)
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, ui)
        projection = p
        Thread { prepare(lang) }.start()
    }

    private fun addOverlay() {
        val v = TextView(this)
        v.setShadowLayer(6f, 0f, 0f, Color.BLACK)
        v.setBackgroundColor(Color.argb(120, 0, 0, 0))
        v.setPadding(24, 12, 24, 12)
        v.gravity = Gravity.CENTER
        v.text = "Đang khởi động..."
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.BOTTOM
        lp.y = 60
        wm.addView(v, lp)
        tv = v
    }

    private fun applyStyle(i: Intent) {
        tv?.textSize = i.getFloatExtra("size", 22f)
        tv?.setTextColor(i.getIntExtra("color", Color.WHITE))
    }

    // Hiện trạng thái (không tự tắt)
    private fun status(s: String) {
        ui.post {
            tv?.text = s
            tv?.visibility = View.VISIBLE
            ui.removeCallbacks(clearer)
        }
    }

    // Hiện phụ đề (tự tắt sau 6 giây)
    private fun show(s: String) {
        tv?.text = s
        tv?.visibility = if (s.isEmpty()) View.GONE else View.VISIBLE
        ui.removeCallbacks(clearer)
        if (s.isNotEmpty()) ui.postDelayed(clearer, 6000)
    }

    private fun prepare(lang: String) {
        try {
            val name = if (lang == "zh") "vosk-model-small-cn-0.22" else "vosk-model-small-en-us-0.15"
            val dir = File(filesDir, "models/$name")
            if (!File(dir, ".ok").exists()) {
                dir.deleteRecursively()
                download(name)
            }
            status("Đang nạp mô hình giọng nói...")
            val model = Model(dir.absolutePath)
            ui.post { loadTranslator(lang, model) }
        } catch (e: Exception) {
            status("Lỗi: ${e.message}")
        }
    }

    private fun download(name: String) {
        val base = File(filesDir, "models")
        base.mkdirs()
        val zip = File(base, "$name.zip")
        val c = URL("https://alphacephei.com/vosk/models/$name.zip").openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        val total = c.contentLength
        var done = 0L
        var last = -1
        c.inputStream.use { inp ->
            FileOutputStream(zip).use { out ->
                val b = ByteArray(65536)
                while (true) {
                    val n = inp.read(b)
                    if (n < 0) break
                    out.write(b, 0, n)
                    done += n
                    if (total > 0) {
                        val pct = (done * 100 / total).toInt()
                        if (pct != last) {
                            last = pct
                            status("Đang tải mô hình giọng nói (lần đầu): $pct%")
                        }
                    }
                }
            }
        }
        status("Đang giải nén...")
        ZipInputStream(zip.inputStream()).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                val f = File(base, e.name)
                if (!f.canonicalPath.startsWith(base.canonicalPath)) continue
                if (e.isDirectory) {
                    f.mkdirs()
                } else {
                    f.parentFile?.mkdirs()
                    FileOutputStream(f).use { z.copyTo(it) }
                }
            }
        }
        zip.delete()
        File(base, "$name/.ok").writeText("ok")
    }

    private fun loadTranslator(lang: String, model: Model) {
        val src = if (lang == "zh") TranslateLanguage.CHINESE else TranslateLanguage.ENGLISH
        val t = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(src)
                .setTargetLanguage(TranslateLanguage.VIETNAMESE)
                .build()
        )
        translator = t
        status("Đang tải mô hình dịch (lần đầu)...")
        t.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                status("Sẵn sàng. Hãy phát video hoặc game...")
                Thread { capture(model, lang) }.start()
            }
            .addOnFailureListener { status("Lỗi tải mô hình dịch: ${it.message}") }
    }

    private fun translate(text: String) {
        val id = ++seq
        translator?.translate(text)?.addOnSuccessListener { r ->
            if (id > applied) {
                applied = id
                show(r)
            }
        }
    }

    private fun capture(model: Model, lang: String) {
        val p = projection ?: return
        val cfg = AudioPlaybackCaptureConfiguration.Builder(p)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()
        val fmt = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(16000)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()
        val ar: AudioRecord
        try {
            ar = AudioRecord.Builder()
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(32000)
                .setAudioPlaybackCaptureConfig(cfg)
                .build()
        } catch (e: Exception) {
            status("Không thu được âm thanh: ${e.message}")
            return
        }
        val rec = Recognizer(model, 16000f)
        ar.startRecording()
        val buf = ByteArray(3200)
        var lastPartial = ""
        var lastT = 0L
        while (running) {
            val n = ar.read(buf, 0, buf.size)
            if (n < 0) break
            if (n == 0) continue
            if (rec.acceptWaveForm(buf, n)) {
                val t = JSONObject(rec.result).optString("text")
                lastPartial = ""
                if (t.isNotBlank()) {
                    val s = if (lang == "zh") t.replace(" ", "") else t
                    ui.post { translate(s) }
                }
            } else {
                val t = JSONObject(rec.partialResult).optString("partial")
                val now = SystemClock.elapsedRealtime()
                if (t.isNotBlank() && t != lastPartial && now - lastT > 800) {
                    lastPartial = t
                    lastT = now
                    val s = if (lang == "zh") t.replace(" ", "") else t
                    ui.post { translate(s) }
                }
            }
        }
        ar.stop()
        ar.release()
        rec.close()
        model.close()
    }

    override fun onDestroy() {
        running = false
        ui.removeCallbacksAndMessages(null)
        projection?.stop()
        translator?.close()
        tv?.let { wm.removeView(it) }
        super.onDestroy()
    }
}
