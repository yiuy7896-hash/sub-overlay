package com.example.subtitle

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class OverlayService : Service() {
    private var tv: TextView? = null
    private lateinit var wm: WindowManager

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val ch = NotificationChannel("sub", "Subtitle", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        val n = Notification.Builder(this, "sub")
            .setContentTitle("Sub Overlay đang chạy")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        startForeground(1, n)

        val v = TextView(this)
        v.setShadowLayer(6f, 0f, 0f, Color.BLACK)
        v.setBackgroundColor(Color.argb(120, 0, 0, 0))
        v.setPadding(24, 12, 24, 12)
        v.gravity = Gravity.CENTER
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.BOTTOM
        lp.y = 60
        wm.addView(v, lp)
        tv = v
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent != null) {
            tv?.text = intent.getStringExtra("text") ?: "Xin chào, đây là phụ đề thử"
            tv?.textSize = intent.getFloatExtra("size", 22f)
            tv?.setTextColor(intent.getIntExtra("color", Color.WHITE))
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        tv?.let { wm.removeView(it) }
        super.onDestroy()
    }
}
