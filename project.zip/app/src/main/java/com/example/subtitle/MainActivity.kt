package com.example.subtitle

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private var size = 22f
    private var color = Color.WHITE
    private var running = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(40, 60, 40, 40)

        fun btn(t: String, f: () -> Unit) {
            val b = Button(this)
            b.text = t
            b.setOnClickListener { f() }
            root.addView(b)
        }

        btn("1. Cấp quyền hiển thị trên app khác") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        btn("2. Bật phụ đề thử") { start() }
        btn("Tắt phụ đề") {
            running = false
            stopService(Intent(this, OverlayService::class.java))
        }

        val label = TextView(this)
        label.text = "Cỡ chữ"
        root.addView(label)
        val sb = SeekBar(this)
        sb.max = 40
        sb.progress = 12
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                size = 10f + p
                if (running) start()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(sb)

        val colors = listOf(
            "Trắng" to Color.WHITE, "Vàng" to Color.YELLOW,
            "Xanh lá" to Color.GREEN, "Xanh dương" to Color.CYAN
        )
        for ((name, c) in colors) {
            btn("Màu $name") {
                color = c
                if (running) start()
            }
        }

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Hãy cấp quyền ở bước 1 trước", Toast.LENGTH_LONG).show()
            return
        }
        running = true
        val i = Intent(this, OverlayService::class.java)
            .putExtra("size", size)
            .putExtra("color", color)
        startForegroundService(i)
    }
}
